//SHAINMNT JOB (ACCT),'SHAIN MASTER HOSHU',CLASS=A,
//             MSGCLASS=X,NOTIFY=&SYSUID
//*================================================================*
//* JOB NAME : SHAINMNT                                            *
//* GAIYO    : 社員マスタ保守バッチ ジョブ                         *
//* SHOZOKU  : 人事部 給与計算システム                             *
//* SETSUMEI : 入社・退職・異動・昇給のトランザクションを反映し、   *
//*            社員マスタを更新する。月次給与計算（KYUYOMN）の      *
//*            前提となる先行ジョブ。                              *
//*================================================================*
//STEP01   EXEC PGM=SHAINMNT
//STEPLIB  DD   DSN=JINJI.LOADLIB,DISP=SHR
//*        社員トランザクション（入力）                           *
//SHAINTR  DD   DSN=JINJI.SHAIN.TRAN,DISP=SHR
//*        更新後 社員マスタ（出力）                              *
//SHAINNEW DD   DSN=JINJI.SHAIN.MASTER(+1),
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(20,10),RLSE),
//             DCB=(RECFM=FB,LRECL=256,BLKSIZE=25600)
//SYSOUT   DD   SYSOUT=*
//SYSPRINT DD   SYSOUT=*
//*
