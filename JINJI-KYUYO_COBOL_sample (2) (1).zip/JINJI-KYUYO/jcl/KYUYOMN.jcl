//KYUYOMN  JOB (ACCT),'GETSUJI KYUYO KEISAN',CLASS=A,
//             MSGCLASS=X,NOTIFY=&SYSUID
//*================================================================*
//* JOB NAME : KYUYOMN                                             *
//* GAIYO    : 月次給与計算バッチ ジョブ                           *
//* SHOZOKU  : 人事部 給与計算システム                             *
//* SETSUMEI : 社員マスタを入力に給与計算を実行し、給与ファイルと   *
//*            給与明細帳票を出力する。毎月25日支給の5営業日前に     *
//*            実行する運用。                                       *
//*================================================================*
//*--------------------------------------------------------------*
//* STEP01 : 給与計算メイン処理                                   *
//*--------------------------------------------------------------*
//STEP01   EXEC PGM=KYUYOMN
//STEPLIB  DD   DSN=JINJI.LOADLIB,DISP=SHR
//*        社員マスタ（入力）                                     *
//SHAINMST DD   DSN=JINJI.SHAIN.MASTER,DISP=SHR
//*        給与結果ファイル（出力）                               *
//KYUYOFL  DD   DSN=JINJI.KYUYO.RESULT(+1),
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(10,5),RLSE),
//             DCB=(RECFM=FB,LRECL=128,BLKSIZE=12800)
//*        給与明細帳票（出力）                                   *
//MEISAIRP DD   SYSOUT=*
//SYSOUT   DD   SYSOUT=*
//SYSPRINT DD   SYSOUT=*
//*
//*--------------------------------------------------------------*
//* STEP02 : 給与振込データ作成（正常終了時のみ）                 *
//*--------------------------------------------------------------*
//STEP02   EXEC PGM=FURIKOMI,COND=(0,NE,STEP01)
//STEPLIB  DD   DSN=JINJI.LOADLIB,DISP=SHR
//KYUYOFL  DD   DSN=JINJI.KYUYO.RESULT(+1),DISP=SHR
//FBDATA   DD   DSN=JINJI.FURIKOMI.ZENGIN,
//             DISP=(NEW,CATLG,DELETE),
//             SPACE=(CYL,(5,2),RLSE)
//SYSOUT   DD   SYSOUT=*
//*
