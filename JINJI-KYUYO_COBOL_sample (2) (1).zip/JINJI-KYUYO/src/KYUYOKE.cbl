      *================================================================*
      * PROGRAM-ID  : KYUYOKE                                          *
      * SHISTEM     : 人事給与計算システム                            *
      * SHOZOKU     : 人事部 給与計算システム                          *
      * 概要        : 給与計算サブルーチン。1名分の社員情報を受け取り、*
      *               総支給額・社会保険料・税額・差引支給額を計算して  *
      *               給与レコードを編集し、呼び出し元へ返す。          *
      * 呼び出し元  : KYUYOMN（月次給与計算メイン）                    *
      * 連絡領域    : 社員レコード／給与レコード／計算対象年月          *
      * 作成        : 1987-04-01                                       *
      * 改訂履歴    :                                                  *
      *   2000-04-01 介護保険料計算追加                                *
      *   2003-04-01 総報酬制対応（賞与含む通年計算）                  *
      *   2024-04-01 保険料率改定（HOKENRTE COPYBOOK改修）             *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. KYUYOKE.
       AUTHOR. JINJI-SYSTEM-TEAM.
      *
       ENVIRONMENT DIVISION.
      *
       DATA DIVISION.
       WORKING-STORAGE SECTION.
      *       保険料率テーブルの取り込み                               *
       COPY HOKENRTE.
      *---------------- 計算ワークエリア ------------------------------*
       01  WK-KEISAN.
      *       年齢（介護保険判定用）                                   *
           05  WK-AGE                PIC 9(03) VALUE 0.
      *       総支給額（途中計算）                                     *
           05  WK-SOSHIKYU-W         PIC 9(09) VALUE 0.
      *       各種保険料（途中計算・端数処理前）                       *
           05  WK-KENKO-W            PIC 9(09)V99 VALUE 0.
           05  WK-KAIGO-W            PIC 9(09)V99 VALUE 0.
           05  WK-KOSEI-W            PIC 9(09)V99 VALUE 0.
           05  WK-KOYO-W             PIC 9(09)V99 VALUE 0.
      *       課税対象額                                               *
           05  WK-KAZEI              PIC 9(09) VALUE 0.
      *       所得税（途中計算）                                       *
           05  WK-SHOTOKU-W          PIC 9(09)V99 VALUE 0.
      *       控除合計                                                 *
           05  WK-KOJO-W             PIC 9(09) VALUE 0.
      *       現在年（年齢計算用・本来はシステム日付から取得）         *
           05  WK-NOW-YEAR           PIC 9(04) VALUE 2024.
      *       生年月日 文字列化エリア（年抽出用）                      *
       01  WK-SEINEN-X.
           05  WK-SEINEN-YYYY        PIC 9(04).
           05  WK-SEINEN-MMDD        PIC 9(04).
      *
      *---------------- 連絡領域（呼び出し元と共有） ------------------*
       LINKAGE SECTION.
       COPY SHAINREC.
       COPY KYUYOREC.
       01  LK-KEISAN-YM              PIC 9(06).
      *
       PROCEDURE DIVISION USING SHAIN-RECORD
                                KYUYO-RECORD
                                LK-KEISAN-YM.
      *================================================================*
      * 主制御                                                         *
      *================================================================*
       CALC-MAIN-RTN.
           PERFORM CALC-SHIKYU-RTN
           PERFORM CALC-HOKEN-RTN
           PERFORM CALC-ZEI-RTN
           PERFORM CALC-SASHIHIKI-RTN
           GOBACK.
      *
      *----------------------------------------------------------------*
      * 支給額計算：基本給＋各種手当                                   *
      *----------------------------------------------------------------*
       CALC-SHIKYU-RTN.
      *       総支給額 ＝ 基本給 ＋ 役職手当 ＋ 通勤手当               *
      *                  ＋ 住宅手当 ＋ 家族手当                       *
      *       （注：残業代は別システムから連携される想定のため         *
      *         本サンプルでは0固定）                                  *
           COMPUTE WK-SOSHIKYU-W =
               KIHONKYU         +
               YAKUSHOKU-TEATE  +
               TSUKIN-TEATE     +
               JUTAKU-TEATE     +
               KAZOKU-TEATE    
      *       給与レコードへ各支給項目を転記                           *
           MOVE SHAIN-NO         
               TO KY-SHAIN-NO    
           MOVE LK-KEISAN-YM      TO KY-KEISAN-YM
           MOVE KIHONKYU         
               TO KY-KIHONKYU    
           MOVE YAKUSHOKU-TEATE  
               TO KY-YAKUSHOKU-TEATE
           MOVE TSUKIN-TEATE     
               TO KY-TSUKIN-TEATE
           MOVE JUTAKU-TEATE     
               TO KY-JUTAKU-TEATE
           MOVE KAZOKU-TEATE     
               TO KY-KAZOKU-TEATE
           MOVE 0                 TO KY-ZANGYO-TEATE
           MOVE WK-SOSHIKYU-W     TO KY-SOSHIKYU.
      *
      *----------------------------------------------------------------*
      * 社会保険料計算                                                 *
      *  健康保険・介護保険・厚生年金・雇用保険                        *
      *----------------------------------------------------------------*
       CALC-HOKEN-RTN.
      *       健康保険料 ＝ 総支給額 × 健康保険料率                   *
           COMPUTE WK-KENKO-W =
               WK-SOSHIKYU-W * R-KENKO-RITSU
           MOVE WK-KENKO-W TO KY-KENKO-HOKEN
      *
      *       介護保険料 ＝ 40歳以上のみ徴収                           *
      *       年齢 ＝ 現在年 － 生年（簡易計算）                       *
           MOVE SEINEN-GAPPI TO WK-SEINEN-X
           COMPUTE WK-AGE =
               WK-NOW-YEAR - WK-SEINEN-YYYY
           IF WK-AGE >= R-KAIGO-AGE
               COMPUTE WK-KAIGO-W =
                   WK-SOSHIKYU-W * R-KAIGO-RITSU
               MOVE WK-KAIGO-W TO KY-KAIGO-HOKEN
           ELSE
               MOVE 0 TO KY-KAIGO-HOKEN
           END-IF
      *
      *       厚生年金保険料 ＝ 総支給額 × 厚生年金料率               *
           COMPUTE WK-KOSEI-W =
               WK-SOSHIKYU-W * R-KOSEI-RITSU
           MOVE WK-KOSEI-W TO KY-KOSEI-NENKIN
      *
      *       雇用保険料 ＝ 総支給額 × 雇用保険料率                   *
           COMPUTE WK-KOYO-W =
               WK-SOSHIKYU-W * R-KOYO-RITSU
           MOVE WK-KOYO-W TO KY-KOYO-HOKEN.
      *
      *----------------------------------------------------------------*
      * 税額計算：所得税（源泉徴収）・住民税                           *
      *----------------------------------------------------------------*
       CALC-ZEI-RTN.
      *       課税対象額 ＝ 総支給額 － 社会保険料合計                 *
      *                     － 基礎控除 － 扶養控除                    *
           COMPUTE WK-KAZEI =
               WK-SOSHIKYU-W
               - KY-KENKO-HOKEN 
               - KY-KAIGO-HOKEN 
               - KY-KOSEI-NENKIN
               - KY-KOYO-HOKEN  
               - R-KISO-KOJO
               - (R-FUYO-KOJO * FUYO-NINZU)
      *       課税対象額がマイナスの場合は0とする                     *
           IF WK-KAZEI < 0
               MOVE 0 TO WK-KAZEI
           END-IF
      *       所得税 ＝ 課税対象額 × 税率（簡易：一律5.105%）         *
      *       （注：本来は源泉徴収税額表を参照すべき。               *
      *         本サンプルでは復興特別所得税込みの簡易税率を使用）     *
           COMPUTE WK-SHOTOKU-W = WK-KAZEI * 0.05105
           MOVE WK-SHOTOKU-W TO KY-SHOTOKUZEI
      *       住民税 ＝ 課税対象額 × 10%（簡易計算）                  *
      *       （注：住民税は前年所得ベースで別途通知される金額を       *
      *         セットするのが正しい。本サンプルは簡易計算）           *
           COMPUTE KY-JUMINZEI = WK-KAZEI * 0.10.
      *
      *----------------------------------------------------------------*
      * 差引支給額計算（手取り）                                       *
      *----------------------------------------------------------------*
       CALC-SASHIHIKI-RTN.
      *       控除合計 ＝ 各種保険料 ＋ 所得税 ＋ 住民税              *
           COMPUTE WK-KOJO-W =
               KY-KENKO-HOKEN   +
               KY-KAIGO-HOKEN   +
               KY-KOSEI-NENKIN  +
               KY-KOYO-HOKEN    +
               KY-SHOTOKUZEI    +
               KY-JUMINZEI     
           MOVE WK-KOJO-W TO KY-KOJO-GOKEI
      *       差引支給額 ＝ 総支給額 － 控除合計                       *
           COMPUTE KY-SASHIHIKI =
               KY-SOSHIKYU   -
               KY-KOJO-GOKEI.
