      *================================================================*
      * PROGRAM-ID  : KYUYOPR                                          *
      * SHISTEM     : 人事給与計算システム                            *
      * SHOZOKU     : 人事部 給与計算システム                          *
      * 概要        : 給与明細帳票出力サブルーチン。                  *
      *               給与結果ファイルを順次読み込み、社員ごとの        *
      *               給与明細書を印刷イメージ（行）として出力する。    *
      * 呼び出し元  : KYUYOMN（月次給与計算メイン）                    *
      * 出力先      : 帳票スプール（本サンプルでは表示）               *
      * 作成        : 1987-04-01                                       *
      * 改訂履歴    :                                                  *
      *   2020-04-01 Web給与明細システム連携用CSV出力を追加（別途）     *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. KYUYOPR.
       AUTHOR. JINJI-SYSTEM-TEAM.
      *
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *       給与結果ファイル（入力）                                 *
           SELECT KYUYO-FILE  ASSIGN TO "KYUYOFL"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-KYUYO-STATUS.
      *       給与明細帳票（出力）                                     *
           SELECT MEISAI-RPT  ASSIGN TO "MEISAIRP"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-RPT-STATUS.
      *
       DATA DIVISION.
       FILE SECTION.
       FD  KYUYO-FILE.
       COPY KYUYOREC.
      *
       FD  MEISAI-RPT.
       01  RPT-LINE                  PIC X(120).
      *
       WORKING-STORAGE SECTION.
       01  WK-STATUS.
           05  WK-KYUYO-STATUS       PIC X(02) VALUE SPACE.
           05  WK-RPT-STATUS         PIC X(02) VALUE SPACE.
       01  WK-FLAGS.
           05  WK-EOF                PIC 9(01) VALUE 0.
               88  END-OF-KYUYO                VALUE 1.
      *---------------- 帳票編集エリア --------------------------------*
       01  WK-EDIT.
           05  WK-EDIT-KIN           PIC ZZZ,ZZZ,ZZ9.
      *---------------- 帳票見出し行 ----------------------------------*
       01  RPT-HEADER1.
           05  FILLER  PIC X(45) VALUE
               "========== 給与明細書 ==========".
       01  RPT-HEADER2.
           05  FILLER  PIC X(20) VALUE "対象年月 : ".
           05  RPT-YM                PIC 9(06).
      *---------------- 給与明細 行 -----------------------------------*
       01  RPT-DETAIL-SHAIN.
           05  FILLER  PIC X(20) VALUE "社員番号 : ".
           05  RPT-SHAIN-NO          PIC 9(07).
       01  RPT-DETAIL-LINE.
           05  RPT-KOMOKU            PIC X(20).
           05  FILLER  PIC X(03) VALUE " : ".
           05  RPT-KINGAKU           PIC X(15).
      *
       LINKAGE SECTION.
       01  LK-KEISAN-YM              PIC 9(06).
      *
       PROCEDURE DIVISION USING LK-KEISAN-YM.
      *================================================================*
      * 主制御                                                         *
      *================================================================*
       PRINT-MAIN-RTN.
           PERFORM PRINT-INIT-RTN
           PERFORM PRINT-LOOP-RTN
               UNTIL END-OF-KYUYO
           PERFORM PRINT-TERM-RTN
           GOBACK.
      *
      *----------------------------------------------------------------*
      * 初期処理                                                       *
      *----------------------------------------------------------------*
       PRINT-INIT-RTN.
           OPEN INPUT  KYUYO-FILE
           OPEN OUTPUT MEISAI-RPT
      *       帳票見出し出力                                           *
           MOVE RPT-HEADER1 TO RPT-LINE
           WRITE RPT-LINE
           MOVE LK-KEISAN-YM TO RPT-YM
           MOVE RPT-HEADER2 TO RPT-LINE
           WRITE RPT-LINE
           PERFORM READ-KYUYO-RTN.
      *
      *----------------------------------------------------------------*
      * 主ループ：1名分の明細を出力                                   *
      *----------------------------------------------------------------*
       PRINT-LOOP-RTN.
      *       社員番号行                                               *
           MOVE KY-SHAIN-NO TO RPT-SHAIN-NO
           MOVE RPT-DETAIL-SHAIN TO RPT-LINE
           WRITE RPT-LINE
      *       総支給額                                                 *
           MOVE "総支給額"          TO RPT-KOMOKU
           MOVE KY-SOSHIKYU         TO WK-EDIT-KIN
           MOVE WK-EDIT-KIN         TO RPT-KINGAKU
           MOVE RPT-DETAIL-LINE     TO RPT-LINE
           WRITE RPT-LINE
      *       控除合計                                                 *
           MOVE "控除合計"          TO RPT-KOMOKU
           MOVE KY-KOJO-GOKEI       TO WK-EDIT-KIN
           MOVE WK-EDIT-KIN         TO RPT-KINGAKU
           MOVE RPT-DETAIL-LINE     TO RPT-LINE
           WRITE RPT-LINE
      *       差引支給額（手取り）                                     *
           MOVE "差引支給額(手取り)" TO RPT-KOMOKU
           MOVE KY-SASHIHIKI        TO WK-EDIT-KIN
           MOVE WK-EDIT-KIN         TO RPT-KINGAKU
           MOVE RPT-DETAIL-LINE     TO RPT-LINE
           WRITE RPT-LINE
           PERFORM READ-KYUYO-RTN.
      *
      *----------------------------------------------------------------*
      * 給与結果ファイル読込                                           *
      *----------------------------------------------------------------*
       READ-KYUYO-RTN.
           READ KYUYO-FILE
               AT END
                   SET END-OF-KYUYO TO TRUE
           END-READ.
      *
      *----------------------------------------------------------------*
      * 終了処理                                                       *
      *----------------------------------------------------------------*
       PRINT-TERM-RTN.
           CLOSE KYUYO-FILE
                 MEISAI-RPT.
