      *================================================================*
      * PROGRAM-ID  : SHAINMNT                                         *
      * SHISTEM     : 人事給与計算システム（社員マスタ保守）           *
      * SHOZOKU     : 人事部 給与計算システム                          *
      * 概要        : 社員マスタの保守処理。トランザクションファイル    *
      *               （入社・退職・異動・昇給）を読み込み、社員マスタ  *
      *               を更新する。区分により追加・変更・削除を行う。    *
      * 処理方式    : バッチ（マッチング更新）                          *
      * 起動JCL     : SHAINMNT.JCL                                     *
      * 作成        : 1987-04-01                                       *
      * 改訂履歴    :                                                  *
      *   2003-04-01 役職コード体系の見直し                            *
      *   2016-01-01 マイナンバー対応（別ファイルで暗号管理：本体対象外）*
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SHAINMNT.
       AUTHOR. JINJI-SYSTEM-TEAM.
      *
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *       社員トランザクション（入力）                            *
           SELECT SHAIN-TRAN  ASSIGN TO "SHAINTR"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-TRAN-STATUS.
      *       社員マスタ（更新後・出力）                               *
           SELECT SHAIN-NEW   ASSIGN TO "SHAINNEW"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-NEW-STATUS.
      *
       DATA DIVISION.
       FILE SECTION.
       FD  SHAIN-TRAN.
       01  TRAN-RECORD.
      *       処理区分（1:追加 2:変更 3:削除）                         *
           05  TR-KBN                PIC 9(01).
      *       社員レコード本体（256バイト・SHAINRECと同一レイアウト）  *
           05  TR-SHAIN-DATA         PIC X(256).
      *
       FD  SHAIN-NEW.
       COPY SHAINREC.
      *
       WORKING-STORAGE SECTION.
       01  WK-STATUS.
           05  WK-TRAN-STATUS        PIC X(02) VALUE SPACE.
           05  WK-NEW-STATUS         PIC X(02) VALUE SPACE.
       01  WK-FLAGS.
           05  WK-EOF                PIC 9(01) VALUE 0.
               88  END-OF-TRAN                 VALUE 1.
       01  WK-CNT.
           05  WK-ADD-CNT            PIC 9(07) VALUE 0.
           05  WK-UPD-CNT            PIC 9(07) VALUE 0.
           05  WK-DEL-CNT            PIC 9(07) VALUE 0.
      *
       PROCEDURE DIVISION.
       MNT-MAIN-RTN.
           PERFORM MNT-INIT-RTN
           PERFORM MNT-LOOP-RTN
               UNTIL END-OF-TRAN
           PERFORM MNT-TERM-RTN
           STOP RUN.
      *
       MNT-INIT-RTN.
           DISPLAY "*** 社員マスタ保守バッチ 開始 ***"
           OPEN INPUT  SHAIN-TRAN
           OPEN OUTPUT SHAIN-NEW
           PERFORM READ-TRAN-RTN.
      *
      *----------------------------------------------------------------*
      * 処理区分により分岐                                             *
      *----------------------------------------------------------------*
       MNT-LOOP-RTN.
           EVALUATE TR-KBN
               WHEN 1
                   PERFORM ADD-RTN
               WHEN 2
                   PERFORM UPDATE-RTN
               WHEN 3
                   PERFORM DELETE-RTN
               WHEN OTHER
                   DISPLAY "不正な処理区分 : " TR-KBN
           END-EVALUATE
           PERFORM READ-TRAN-RTN.
      *
      *       追加：新規社員レコードをそのまま書き出し                 *
       ADD-RTN.
           MOVE TR-SHAIN-DATA TO SHAIN-RECORD
      *       在籍区分を「在籍」に設定                                 *
           MOVE 1 TO ZAISEKI-KBN
           WRITE SHAIN-RECORD
           ADD 1 TO WK-ADD-CNT.
      *
      *       変更：変更内容を反映して書き出し                         *
       UPDATE-RTN.
           MOVE TR-SHAIN-DATA TO SHAIN-RECORD
           WRITE SHAIN-RECORD
           ADD 1 TO WK-UPD-CNT.
      *
      *       削除：在籍区分を「退職」に設定して論理削除               *
       DELETE-RTN.
           MOVE TR-SHAIN-DATA TO SHAIN-RECORD
           MOVE 9 TO ZAISEKI-KBN
           WRITE SHAIN-RECORD
           ADD 1 TO WK-DEL-CNT.
      *
       READ-TRAN-RTN.
           READ SHAIN-TRAN
               AT END
                   SET END-OF-TRAN TO TRUE
           END-READ.
      *
       MNT-TERM-RTN.
           CLOSE SHAIN-TRAN
                 SHAIN-NEW
           DISPLAY "*** 社員マスタ保守バッチ 終了 ***"
           DISPLAY "*** 追加 : " WK-ADD-CNT
           DISPLAY "*** 変更 : " WK-UPD-CNT
           DISPLAY "*** 削除 : " WK-DEL-CNT.
