      *================================================================*
      * PROGRAM-ID  : SHOYOKE                                          *
      * SHISTEM     : 人事給与計算システム（賞与計算）                 *
      * SHOZOKU     : 人事部 給与計算システム                          *
      * 概要        : 賞与（ボーナス）計算バッチ。社員マスタを読み込み、*
      *               基本給に支給月数と人事評価係数を乗じて賞与額を    *
      *               算出し、社会保険料・所得税を控除する。            *
      * 処理方式    : バッチ（順編成）                                  *
      * 起動JCL     : SHOYOKE.JCL                                      *
      * 作成        : 1990-06-01                                       *
      * 改訂履歴    :                                                  *
      *   2003-04-01 総報酬制対応（賞与からも社会保険料を徴収）         *
      *   2024-04-01 保険料率改定                                      *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. SHOYOKE.
       AUTHOR. JINJI-SYSTEM-TEAM.
      *
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT SHAIN-MASTER ASSIGN TO "SHAINMST"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-SHAIN-STATUS.
           SELECT SHOYO-FILE   ASSIGN TO "SHOYOFL"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-SHOYO-STATUS.
      *
       DATA DIVISION.
       FILE SECTION.
       FD  SHAIN-MASTER.
       COPY SHAINREC.
      *
       FD  SHOYO-FILE.
       01  SHOYO-RECORD.
           05  SY-SHAIN-NO           PIC 9(07).
           05  SY-SHIKYU-YM          PIC 9(06).
      *       賞与総支給額                                             *
           05  SY-SOSHIKYU           PIC 9(09).
      *       社会保険料合計                                           *
           05  SY-HOKEN-GOKEI        PIC 9(08).
      *       所得税                                                   *
           05  SY-SHOTOKUZEI         PIC 9(08).
      *       差引賞与支給額                                           *
           05  SY-SASHIHIKI          PIC 9(09).
           05  FILLER                PIC X(20).
      *
       WORKING-STORAGE SECTION.
       COPY HOKENRTE.
       01  WK-STATUS.
           05  WK-SHAIN-STATUS       PIC X(02) VALUE SPACE.
           05  WK-SHOYO-STATUS       PIC X(02) VALUE SPACE.
       01  WK-FLAGS.
           05  WK-EOF                PIC 9(01) VALUE 0.
               88  END-OF-FILE                 VALUE 1.
      *---------------- 賞与計算パラメータ ----------------------------*
       01  WK-SHOYO-PARAM.
      *       支給月数（夏季賞与 2.5ヶ月など）                         *
           05  WK-SHIKYU-TSUKISU     PIC 9(01)V9(01) VALUE 2.5.
      *       支給年月                                                 *
           05  WK-SHIKYU-YM          PIC 9(06)       VALUE 202406.
       01  WK-CALC.
           05  WK-HYOKA-KEISU        PIC 9(01)V9(02) VALUE 1.00.
           05  WK-SHOYO-W            PIC 9(09)       VALUE 0.
           05  WK-HOKEN-W            PIC 9(09)V99    VALUE 0.
           05  WK-AGE                PIC 9(03)       VALUE 0.
           05  WK-NOW-YEAR           PIC 9(04)       VALUE 2024.
       01  WK-SEINEN-X.
           05  WK-SEINEN-YYYY        PIC 9(04).
           05  WK-SEINEN-MMDD        PIC 9(04).
       01  WK-CNT.
           05  WK-OUT-CNT            PIC 9(07)       VALUE 0.
      *
       PROCEDURE DIVISION.
       SHOYO-MAIN-RTN.
           PERFORM SHOYO-INIT-RTN
           PERFORM SHOYO-LOOP-RTN
               UNTIL END-OF-FILE
           PERFORM SHOYO-TERM-RTN
           STOP RUN.
      *
       SHOYO-INIT-RTN.
           DISPLAY "*** 賞与計算バッチ 開始 ***"
           DISPLAY "*** 支給年月 : " WK-SHIKYU-YM
           DISPLAY "*** 支給月数 : " WK-SHIKYU-TSUKISU
           OPEN INPUT  SHAIN-MASTER
           OPEN OUTPUT SHOYO-FILE
           PERFORM READ-SHAIN-RTN.
      *
       SHOYO-LOOP-RTN.
           IF ZAISEKI-KBN = 1
               PERFORM CALC-SHOYO-RTN
               WRITE SHOYO-RECORD
               ADD 1 TO WK-OUT-CNT
           END-IF
           PERFORM READ-SHAIN-RTN.
      *
      *----------------------------------------------------------------*
      * 賞与計算                                                       *
      *  賞与額 ＝ 基本給 × 支給月数 × 人事評価係数                  *
      *----------------------------------------------------------------*
       CALC-SHOYO-RTN.
           MOVE SHAIN-NO     TO SY-SHAIN-NO
           MOVE WK-SHIKYU-YM TO SY-SHIKYU-YM
      *       人事評価係数の決定（役職コードで簡易設定）               *
      *       本来は人事評価ファイルから取得すべき項目                 *
           EVALUATE YAKUSHOKU-CODE
               WHEN 05
                   MOVE 1.50 TO WK-HYOKA-KEISU
               WHEN 04
                   MOVE 1.30 TO WK-HYOKA-KEISU
               WHEN 03
                   MOVE 1.15 TO WK-HYOKA-KEISU
               WHEN OTHER
                   MOVE 1.00 TO WK-HYOKA-KEISU
           END-EVALUATE
      *       賞与総支給額の計算                                       *
           COMPUTE WK-SHOYO-W =
               KIHONKYU * WK-SHIKYU-TSUKISU * WK-HYOKA-KEISU
           MOVE WK-SHOYO-W TO SY-SOSHIKYU
      *       賞与からの社会保険料（健康・厚生年金・雇用・介護）       *
           MOVE SEINEN-GAPPI TO WK-SEINEN-X
           COMPUTE WK-AGE = WK-NOW-YEAR - WK-SEINEN-YYYY
           IF WK-AGE >= R-KAIGO-AGE
               COMPUTE WK-HOKEN-W = WK-SHOYO-W *
                   (R-KENKO-RITSU + R-KAIGO-RITSU +
                    R-KOSEI-RITSU + R-KOYO-RITSU)
           ELSE
               COMPUTE WK-HOKEN-W = WK-SHOYO-W *
                   (R-KENKO-RITSU + R-KOSEI-RITSU + R-KOYO-RITSU)
           END-IF
           MOVE WK-HOKEN-W TO SY-HOKEN-GOKEI
      *       賞与の所得税（賞与は別税率：簡易6.126%）                 *
           COMPUTE SY-SHOTOKUZEI =
               (WK-SHOYO-W - WK-HOKEN-W) * 0.06126
      *       差引賞与支給額                                           *
           COMPUTE SY-SASHIHIKI =
               SY-SOSHIKYU - SY-HOKEN-GOKEI - SY-SHOTOKUZEI.
      *
       READ-SHAIN-RTN.
           READ SHAIN-MASTER
               AT END
                   SET END-OF-FILE TO TRUE
           END-READ.
      *
       SHOYO-TERM-RTN.
           CLOSE SHAIN-MASTER
                 SHOYO-FILE
           DISPLAY "*** 賞与計算バッチ 終了 ***"
           DISPLAY "*** 計算件数 : " WK-OUT-CNT.
