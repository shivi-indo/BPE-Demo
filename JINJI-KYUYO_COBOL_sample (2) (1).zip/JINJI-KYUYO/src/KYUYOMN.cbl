      *================================================================*
      * PROGRAM-ID  : KYUYOMN                                          *
      * SHISTEM     : 人事給与計算システム（月次給与計算バッチ）        *
      * SHOZOKU     : 人事部 給与計算システム                          *
      * 概要        : 月次給与計算処理のメインプログラム。              *
      *               社員マスタを順次読み込み、在籍者について          *
      *               給与計算サブルーチン（KYUYOKE）を呼び出し、       *
      *               計算結果を給与ファイルへ書き出す。最後に          *
      *               帳票出力サブルーチン（KYUYOPR）を呼び出す。       *
      * 処理方式    : バッチ（順編成→VSAM）                            *
      * 起動JCL     : KYUYOMN.JCL                                      *
      * 作成        : 1987-04-01                                       *
      * 改訂履歴    :                                                  *
      *   1995-04-01 消費税率改定対応（廃止：給与には無関係）           *
      *   2000-04-01 介護保険制度対応                                  *
      *   2003-04-01 総報酬制対応                                      *
      *   2020-04-01 給与振込デジタル化対応                            *
      *================================================================*
       IDENTIFICATION DIVISION.
       PROGRAM-ID. KYUYOMN.
       AUTHOR. JINJI-SYSTEM-TEAM.
      *
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
      *       社員マスタ（入力・順編成）                               *
           SELECT SHAIN-MASTER ASSIGN TO "SHAINMST"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-SHAIN-STATUS.
      *       給与結果ファイル（出力・順編成）                         *
           SELECT KYUYO-FILE   ASSIGN TO "KYUYOFL"
               ORGANIZATION IS LINE SEQUENTIAL
               FILE STATUS IS WK-KYUYO-STATUS.
      *
       DATA DIVISION.
       FILE SECTION.
       FD  SHAIN-MASTER.
       COPY SHAINREC.
      *
       FD  KYUYO-FILE.
       COPY KYUYOREC.
      *
       WORKING-STORAGE SECTION.
      *---------------- ファイルステータス ----------------------------*
       01  WK-FILE-STATUS.
           05  WK-SHAIN-STATUS       PIC X(02) VALUE SPACE.
           05  WK-KYUYO-STATUS       PIC X(02) VALUE SPACE.
      *---------------- 制御フラグ ------------------------------------*
       01  WK-FLAGS.
           05  WK-EOF-FLAG           PIC 9(01) VALUE 0.
               88  END-OF-FILE                 VALUE 1.
      *---------------- カウンタ --------------------------------------*
       01  WK-COUNTERS.
           05  WK-READ-CNT           PIC 9(07) VALUE 0.
           05  WK-WRITE-CNT          PIC 9(07) VALUE 0.
           05  WK-SKIP-CNT           PIC 9(07) VALUE 0.
      *---------------- 計算対象年月（パラメータ） --------------------*
       01  WK-PARAM.
           05  WK-KEISAN-YM          PIC 9(06) VALUE 202404.
      *---------------- 計算対象年月（受け渡し用） --------------------*
      *       （社員レコード・給与レコードはFDの領域を直接受け渡す）   *
      *
       PROCEDURE DIVISION.
      *================================================================*
      * 主制御                                                         *
      *================================================================*
       MAIN-RTN.
           PERFORM INIT-RTN
           PERFORM MAIN-LOOP-RTN
               UNTIL END-OF-FILE
           PERFORM TERM-RTN
           STOP RUN.
      *
      *----------------------------------------------------------------*
      * 初期処理：ファイルOPEN                                         *
      *----------------------------------------------------------------*
       INIT-RTN.
           DISPLAY "*** 月次給与計算バッチ 開始 ***"
           DISPLAY "*** 計算対象年月 : " WK-KEISAN-YM
           OPEN INPUT  SHAIN-MASTER
           OPEN OUTPUT KYUYO-FILE
           IF WK-SHAIN-STATUS NOT = "00"
               DISPLAY "社員マスタOPENエラー : " WK-SHAIN-STATUS
               STOP RUN
           END-IF
           PERFORM READ-SHAIN-RTN.
      *
      *----------------------------------------------------------------*
      * 主ループ：在籍者の給与計算                                     *
      *----------------------------------------------------------------*
       MAIN-LOOP-RTN.
      *       在籍区分が「1:在籍」の社員のみ計算対象とする             *
           IF ZAISEKI-KBN = 1
      *           給与計算サブルーチン呼び出し                         *
      *           （社員レコード・給与レコードを直接受け渡す）         *
               CALL "KYUYOKE" USING SHAIN-RECORD
                                    KYUYO-RECORD
                                    WK-KEISAN-YM
      *           計算結果を給与ファイルへ書き出し                     *
               WRITE KYUYO-RECORD
               ADD 1 TO WK-WRITE-CNT
           ELSE
      *           休職・退職者はスキップ                               *
               ADD 1 TO WK-SKIP-CNT
           END-IF
           PERFORM READ-SHAIN-RTN.
      *
      *----------------------------------------------------------------*
      * 社員マスタ読込                                                 *
      *----------------------------------------------------------------*
       READ-SHAIN-RTN.
           READ SHAIN-MASTER
               AT END
                   SET END-OF-FILE TO TRUE
               NOT AT END
                   ADD 1 TO WK-READ-CNT
           END-READ.
      *
      *----------------------------------------------------------------*
      * 終了処理：帳票出力呼び出し・ファイルCLOSE                      *
      *----------------------------------------------------------------*
       TERM-RTN.
           CLOSE SHAIN-MASTER
                 KYUYO-FILE
      *       給与明細帳票出力サブルーチン呼び出し                     *
           CALL "KYUYOPR" USING WK-KEISAN-YM
           DISPLAY "*** 給与計算バッチ 終了 ***"
           DISPLAY "*** 読込件数 : " WK-READ-CNT
           DISPLAY "*** 計算件数 : " WK-WRITE-CNT
           DISPLAY "*** 対象外   : " WK-SKIP-CNT.
