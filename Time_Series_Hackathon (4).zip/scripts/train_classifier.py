#scripts/train_classifier.py
import pandas as pd
import numpy as np
import os
from glob import glob
import pickle
from tsfresh import extract_features
from tsfresh.utilities.dataframe_functions import impute
from tsfresh.feature_extraction import EfficientFCParameters
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler
import sys
import traceback

# Add scripts directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from scripts.utils import load_time_series, evaluate_models

def extract_ts_features(data):
    """Robust time series feature extraction"""
    df = pd.DataFrame(data)
    df['id'] = 1  # All data belongs to one time series
    
    try:
        extracted_features = extract_features(
            df, 
            column_id='id', 
            column_value='point_value',
            default_fc_parameters=EfficientFCParameters(),
            impute_function=impute,
            n_jobs=4  # Parallel processing
        )
        # Handle potential NaN values in features
        extracted_features = extracted_features.fillna(0)
        return extracted_features
    except Exception as e:
        print(f"Error extracting features: {str(e)}")
        return None

def train_classifier(data_dir='scripts/data'):
    # Initialize lists to store features and labels
    features = []
    best_models = []
    granularities = []
    processed_files = 0
    
    # Get all granularity folders (daily, hourly, monthly, weekly)
    granularity_folders = [f for f in os.listdir(data_dir) 
                         if os.path.isdir(os.path.join(data_dir, f))]
    
    print(f"Found granularity folders: {granularity_folders}")
    
    for granularity in granularity_folders:
        # Get all CSV files in this granularity folder
        ts_files = glob(os.path.join(data_dir, granularity, '*.csv'))
        print(f"\nProcessing {len(ts_files)} files in {granularity} folder")
        
        for file_idx, file in enumerate(ts_files, 1):
            try:
                print(f"\nProcessing file {file_idx}/{len(ts_files)}: {os.path.basename(file)}")
                
                # Load time series data with robust preprocessing
                ts_data = load_time_series(file)
                
                # Skip if data is too short
                if len(ts_data) < 10:
                    print(f"Skipping {file} - not enough data points")
                    continue
                
                # Extract features
                ts_features = extract_ts_features(ts_data)
                if ts_features is None:
                    print(f"Skipping {file} - feature extraction failed")
                    continue
                
                # Evaluate models and find best one
                try:
                    best_model, mape = evaluate_models(ts_data, granularity)
                    print(f"Best model: {best_model} (MAPE: {mape:.4f})")
                    
                    features.append(ts_features)
                    best_models.append(best_model)
                    granularities.append(granularity)
                    processed_files += 1
                except Exception as e:
                    print(f"Model evaluation failed for {file}: {str(e)}")
                    continue
                
            except Exception as e:
                print(f"Error processing {file}:")
                print(traceback.format_exc())
                continue
    
    if processed_files == 0:
        raise ValueError("No valid time series files could be processed")
    
    print(f"\nSuccessfully processed {processed_files} time series")
    
    # Combine features and labels
    X = pd.concat(features, axis=0)
    y = pd.Series(best_models)
    granularities = pd.Series(granularities)
    
    # Save feature names before scaling
    feature_columns = X.columns.tolist()
    
    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    # Train-test split with stratification by granularity
    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=0.2, random_state=42, stratify=granularities
    )
    
    # Train classifier with balanced class weights
    clf = RandomForestClassifier(
        n_estimators=200,
        random_state=42,
        class_weight='balanced',
        n_jobs=-1,
        verbose=1
    )
    clf.fit(X_train, y_train)
    
    # Evaluate
    y_pred = clf.predict(X_test)
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
    
    # Feature importance
    feature_importance = pd.DataFrame({
        'feature': feature_columns,
        'importance': clf.feature_importances_
    }).sort_values('importance', ascending=False)
    
    print("\nTop 20 Important Features:")
    print(feature_importance.head(20))
    
    # Create models directory if it doesn't exist
    os.makedirs('api/models', exist_ok=True)
    
    # Save models
    with open('api/models/classifier.pkl', 'wb') as f:
        pickle.dump(clf, f)
    
    with open('api/models/scaler.pkl', 'wb') as f:
        pickle.dump(scaler, f)
    
    # Save feature names
    with open('api/models/ts_features.pkl', 'wb') as f:
        pickle.dump(feature_columns, f)
    
    # Save granularity information
    with open('api/models/granularity_info.pkl', 'wb') as f:
        pickle.dump({
            'granularities': granularities,
            'model_distribution': y.value_counts().to_dict(),
            'processed_files': processed_files
        }, f)
    
    print("\nTraining complete!")
    print(f"Final model distribution:\n{y.value_counts()}")

if __name__ == "__main__":
    train_classifier()