import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_percentage_error
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from prophet import Prophet
from sklearn.ensemble import RandomForestRegressor
import warnings
from datetime import datetime
import re
warnings.filterwarnings('ignore')

def clean_column_names(df):
    """Standardize column names"""
    df.columns = [col.strip().lower().replace(' ', '_') for col in df.columns]
    return df

def convert_to_datetime(series):
    """Robust datetime conversion"""
    try:
        return pd.to_datetime(series)
    except:
        # Try different datetime formats
        for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d-%m-%Y', '%Y%m%d', 
                   '%Y-%m-%d %H:%M:%S', '%m/%d/%Y %H:%M:%S']:
            try:
                return pd.to_datetime(series, format=fmt)
            except:
                continue
        return pd.to_datetime(series, errors='coerce')

def load_time_series(file_path):
    """Robust time series data loading with extensive preprocessing"""
    try:
        # Try reading with different encodings
        encodings = ['utf-8', 'latin1', 'iso-8859-1', 'cp1252']
        for encoding in encodings:
            try:
                df = pd.read_csv(file_path, encoding=encoding)
                break
            except:
                continue
        else:
            raise ValueError(f"Could not read file {file_path} with any encoding")

        # Clean column names
        df = clean_column_names(df)

        # Handle different column name patterns
        timestamp_col = None
        value_col = None
        
        # Try to identify timestamp and value columns
        for col in df.columns:
            if col in ['timestamp', 'date', 'time', 'point_timestamp', 'datetime']:
                timestamp_col = col
            elif col in ['value', 'point_value', 'measurement', 'data']:
                value_col = col
        
        # If automatic detection failed, use first two columns
        if not timestamp_col or not value_col:
            if len(df.columns) >= 2:
                timestamp_col = df.columns[0]
                value_col = df.columns[1]
            else:
                raise ValueError("CSV must have at least 2 columns")

        # Select only the two columns we need
        df = df[[timestamp_col, value_col]].copy()
        df.columns = ['point_timestamp', 'point_value']

        # Convert timestamp
        df['point_timestamp'] = convert_to_datetime(df['point_timestamp'])
        
        # Handle value column
        df['point_value'] = pd.to_numeric(df['point_value'], errors='coerce')
        
        # Drop rows with NaT or NaN in timestamp
        df = df[df['point_timestamp'].notna()]
        
        # Sort by timestamp
        df = df.sort_values('point_timestamp')
        
        # Handle missing values
        if df['point_value'].isna().any():
            # Forward fill then backward fill
            df['point_value'] = df['point_value'].ffill().bfill()
            
            # If still missing values, interpolate
            if df['point_value'].isna().any():
                df['point_value'] = df['point_value'].interpolate()
        
        # Drop any remaining rows with NaN values
        df = df.dropna()
        
        # Validate we have enough data
        if len(df) < 10:
            raise ValueError("Not enough valid data points (min 10 required)")
            
        # Check for duplicate timestamps
        if df['point_timestamp'].duplicated().any():
            # Aggregate duplicates by taking mean
            df = df.groupby('point_timestamp').mean().reset_index()
        
        return df
    
    except Exception as e:
        raise ValueError(f"Error processing {file_path}: {str(e)}")

def evaluate_models(ts_data, granularity):
    """Evaluate different time series models with robust error handling"""
    ts_data = ts_data.copy()
    ts_data['point_timestamp'] = pd.to_datetime(ts_data['point_timestamp'])
    ts_data.set_index('point_timestamp', inplace=True)
    ts_data.sort_index(inplace=True)
    
    # Determine test size based on granularity
    if granularity == 'hourly':
        test_size = min(24 * 7, len(ts_data) // 3)  # 1 week of hourly data
    elif granularity == 'daily':
        test_size = min(30, len(ts_data) // 3)  # 1 month of daily data
    elif granularity == 'weekly':
        test_size = min(12, len(ts_data) // 3)  # 3 months of weekly data
    elif granularity == 'monthly':
        test_size = min(12, len(ts_data) // 3)  # 1 year of monthly data
    else:
        test_size = max(5, len(ts_data) // 5)  # default to 20% split
    
    # Ensure we have enough data for train/test split
    if len(ts_data) - test_size < 10:
        test_size = len(ts_data) // 3
        if len(ts_data) - test_size < 10:
            raise ValueError("Not enough data for evaluation")
    
    train = ts_data.iloc[:-test_size]
    test = ts_data.iloc[-test_size:]
    
    models = {
        'ARIMA': None,
        'ETS': None,
        'Prophet': None,
        'RandomForest': None
    }
    
    model_performance = {k: np.inf for k in models.keys()}
    
    # ARIMA
    try:
        # Simple auto-ARIMA implementation
        best_arima_mape = np.inf
        for p in range(3):
            for d in range(2):
                for q in range(3):
                    try:
                        model = ARIMA(train, order=(p,d,q)).fit()
                        pred = model.forecast(steps=len(test))
                        mape = mean_absolute_percentage_error(test, pred)
                        if mape < best_arima_mape:
                            best_arima_mape = mape
                    except:
                        continue
        if best_arima_mape < np.inf:
            model_performance['ARIMA'] = best_arima_mape
    except Exception as e:
        pass
    
    # ETS
    try:
        seasonal_periods = {
            'hourly': 24,
            'daily': 7,
            'weekly': 4,
            'monthly': 12
        }.get(granularity, 12)
        
        # Try different ETS models
        for trend in ['add', 'mul', None]:
            for seasonal in ['add', 'mul', None]:
                try:
                    if len(train) > 2 * seasonal_periods:
                        model = ExponentialSmoothing(
                            train,
                            trend=trend,
                            seasonal=seasonal,
                            seasonal_periods=seasonal_periods
                        ).fit()
                        pred = model.forecast(len(test))
                        mape = mean_absolute_percentage_error(test, pred)
                        if mape < model_performance['ETS']:
                            model_performance['ETS'] = mape
                except:
                    continue
    except Exception as e:
        pass
    
    # Prophet
    try:
        prophet_df = train.reset_index()
        prophet_df.columns = ['ds', 'y']
        
        model = Prophet(
            growth='linear',
            seasonality_mode='additive'
        )
        
        # Add seasonality based on granularity
        if granularity == 'hourly':
            model.add_seasonality(name='daily', period=1, fourier_order=5)
            model.add_seasonality(name='weekly', period=7, fourier_order=3)
        elif granularity == 'daily':
            model.add_seasonality(name='weekly', period=7, fourier_order=3)
        elif granularity == 'weekly':
            model.add_seasonality(name='monthly', period=4, fourier_order=3)
        elif granularity == 'monthly':
            model.add_seasonality(name='yearly', period=12, fourier_order=3)
        
        model.fit(prophet_df)
        future = model.make_future_dataframe(periods=len(test), freq='D')
        pred = model.predict(future)['yhat'][-len(test):]
        model_performance['Prophet'] = mean_absolute_percentage_error(test, pred)
    except Exception as e:
        pass
    
    # Random Forest
    try:
        rf_data = pd.concat([train, test])
        
        # Create time-based features
        rf_data['hour'] = rf_data.index.hour
        rf_data['day'] = rf_data.index.day
        rf_data['month'] = rf_data.index.month
        rf_data['year'] = rf_data.index.year
        rf_data['dayofweek'] = rf_data.index.dayofweek
        rf_data['dayofyear'] = rf_data.index.dayofyear
        rf_data['weekofyear'] = rf_data.index.isocalendar().week
        rf_data['quarter'] = rf_data.index.quarter
        
        X_train = rf_data.iloc[:len(train)].drop('point_value', axis=1)
        y_train = rf_data.iloc[:len(train)]['point_value']
        X_test = rf_data.iloc[len(train):].drop('point_value', axis=1)
        y_test = rf_data.iloc[len(train):]['point_value']
        
        model = RandomForestRegressor(
            n_estimators=100,
            random_state=42,
            n_jobs=-1
        )
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        model_performance['RandomForest'] = mean_absolute_percentage_error(y_test, pred)
    except Exception as e:
        pass
    
    # Find best model (only consider models that succeeded)
    valid_models = {k: v for k, v in model_performance.items() if v < np.inf}
    if not valid_models:
        raise ValueError("No models could be successfully fitted")
    
    best_model = min(valid_models, key=valid_models.get)
    return best_model, valid_models[best_model]

