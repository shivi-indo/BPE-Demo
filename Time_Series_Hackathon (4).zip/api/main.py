from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from datetime import datetime
import pandas as pd
import numpy as np
import pickle
import os
import re
from tsfresh import extract_features
from tsfresh.utilities.dataframe_functions import impute
from tsfresh.feature_extraction import EfficientFCParameters
from statsmodels.tsa.arima.model import ARIMA
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from prophet import Prophet
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_percentage_error
import warnings
from typing import List, Optional
from pydantic import BaseModel, validator
import logging

warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TimeSeriesData(BaseModel):
    timestamp: str
    point_value: float
    
    @validator('timestamp')
    def validate_timestamp(cls, v):
        try:
            # Handle multiple datetime formats
            for fmt in ['%Y-%m-%dT%H:%M:%S', '%d-%m-%Y %H:%M', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d']:
                try:
                    dt = datetime.strptime(v, fmt)
                    return dt.isoformat()
                except ValueError:
                    continue
            raise ValueError(f"Invalid timestamp format: {v}")
        except Exception as e:
            raise ValueError(f"Timestamp validation error: {str(e)}")

class PredictionResult(BaseModel):
    timestamp: str
    point_value: float
    predicted: float
    is_anomaly: str

class ForecastResult(BaseModel):
    forecastability_score: float
    number_of_batch_fits: int
    mape: float
    avg_time_taken_per_fit_in_seconds: float
    best_model: str
    results: List[PredictionResult]

app = FastAPI(title="Time Series Model Selector API")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files for UI
app.mount("/static", StaticFiles(directory="static"), name="static")

# Load models
try:
    model_dir = os.path.join(os.path.dirname(__file__), "models")
    with open(os.path.join(model_dir, "classifier.pkl"), 'rb') as f:
        classifier = pickle.load(f)
    with open(os.path.join(model_dir, "scaler.pkl"), 'rb') as f:
        scaler = pickle.load(f)
    with open(os.path.join(model_dir, "ts_features.pkl"), 'rb') as f:
        feature_columns = pickle.load(f)
except Exception as e:
    logger.error(f"Failed to load models: {str(e)}")
    raise RuntimeError("Failed to initialize models")

def extract_ts_features(data):
    """Extract time series features for classification"""
    try:
        df = pd.DataFrame(data)
        df['id'] = 1  # All data belongs to one time series
        extracted_features = extract_features(
            df, 
            column_id='id', 
            column_value='point_value',
            default_fc_parameters=EfficientFCParameters(),
            impute_function=impute
        )
        # Ensure we have all expected features
        for col in feature_columns:
            if col not in extracted_features:
                extracted_features[col] = 0
        return extracted_features[feature_columns]
    except Exception as e:
        logger.error(f"Feature extraction failed: {str(e)}")
        raise

def predict_with_model(model_name: str, train_data: pd.DataFrame, test_data: pd.DataFrame):
    """Make predictions with the specified model"""
    try:
        train = train_data.copy()
        test = test_data.copy()
        
        train.set_index('timestamp', inplace=True)
        test.set_index('timestamp', inplace=True)
        
        if model_name == 'ARIMA':
            try:
                model = ARIMA(train, order=(1,1,1))
                fitted_model = model.fit()
                predictions = fitted_model.forecast(steps=len(test))
                return predictions.values
            except Exception as e:
                logger.warning(f"ARIMA failed: {str(e)}")
                return None
            
        elif model_name == 'ETS':
            try:
                seasonal_periods = min(12, len(train)//2) if len(train) > 24 else None
                model = ExponentialSmoothing(
                    train, 
                    seasonal='add', 
                    seasonal_periods=seasonal_periods
                )
                fitted_model = model.fit()
                predictions = fitted_model.forecast(len(test))
                return predictions.values
            except Exception as e:
                logger.warning(f"ETS failed: {str(e)}")
                return None
            
        elif model_name == 'Prophet':
            try:
                prophet_df = train.reset_index()
                prophet_df.columns = ['ds', 'y']
                model = Prophet(
                    yearly_seasonality=True,
                    daily_seasonality=len(train) > 48,
                    weekly_seasonality=True
                )
                model.fit(prophet_df)
                future = model.make_future_dataframe(periods=len(test), freq='H')
                predictions = model.predict(future)['yhat'][-len(test):]
                return predictions.values
            except Exception as e:
                logger.warning(f"Prophet failed: {str(e)}")
                return None
            
        elif model_name == 'RandomForest':
            try:
                rf_data = pd.concat([train, test])
                rf_data['hour'] = rf_data.index.hour
                rf_data['day'] = rf_data.index.day
                rf_data['month'] = rf_data.index.month
                rf_data['year'] = rf_data.index.year
                rf_data['dayofweek'] = rf_data.index.dayofweek
                rf_data['dayofyear'] = rf_data.index.dayofyear
                
                X_train = rf_data.iloc[:len(train)].drop('point_value', axis=1)
                y_train = rf_data.iloc[:len(train)]['point_value']
                X_test = rf_data.iloc[len(train):].drop('point_value', axis=1)
                
                model = RandomForestRegressor(n_estimators=100, random_state=42)
                model.fit(X_train, y_train)
                predictions = model.predict(X_test)
                return predictions
            except Exception as e:
                logger.warning(f"RandomForest failed: {str(e)}")
                return None
            
        else:
            raise ValueError(f"Unknown model: {model_name}")
    except Exception as e:
        logger.error(f"Prediction failed for {model_name}: {str(e)}")
        raise

@app.post("/predict", response_model=ForecastResult)
async def predict_time_series(
    data: List[TimeSeriesData],
    date_from: str = Query(..., description="Start date for predictions"),
    date_to: str = Query(..., description="End date for predictions"),
    period: int = Query(0, description="Prediction period")
):
    try:
        # Convert input data to DataFrame
        df = pd.DataFrame([d.dict() for d in data])
        logger.info(f"Received data with {len(df)} points")
        
        # Convert and validate timestamps
        try:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df = df.sort_values('timestamp')
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid timestamp format: {str(e)}"
            )
        
        # Handle single data point case
        if len(df) == 1:
            return {
                "forecastability_score": 5.0,
                "number_of_batch_fits": 1,
                "mape": 0.0,
                "avg_time_taken_per_fit_in_seconds": 0.1,
                "best_model": "SimpleAverage",
                "results": [{
                    "timestamp": df['timestamp'].iloc[0].isoformat(),
                    "point_value": df['point_value'].iloc[0],
                    "predicted": df['point_value'].iloc[0],
                    "is_anomaly": "no"
                }]
            }
        
        # Ensure we have enough data for meaningful prediction
        if len(df) < 5:
            logger.warning("Insufficient data points, using simple average")
            avg_value = df['point_value'].mean()
            return {
                "forecastability_score": 5.0,
                "number_of_batch_fits": 1,
                "mape": 0.0,
                "avg_time_taken_per_fit_in_seconds": 0.1,
                "best_model": "SimpleAverage",
                "results": [{
                    "timestamp": row['timestamp'].isoformat(),
                    "point_value": row['point_value'],
                    "predicted": avg_value,
                    "is_anomaly": "no"
                } for _, row in df.iterrows()]
            }
        
        # Extract features to determine best model
        try:
            features = extract_ts_features(df)
            features_scaled = scaler.transform(features)
            best_model = classifier.predict(features_scaled)[0]
            logger.info(f"Selected model: {best_model}")
        except Exception as e:
            logger.warning(f"Model selection failed, using Prophet as default: {str(e)}")
            best_model = "Prophet"
        
        # Prepare data for prediction
        y = df.set_index('timestamp')['point_value']
        
        # For very small datasets, use all data for training
        if len(y) <= 10:
            train, test = y.iloc[:-1], y.iloc[-1:]
        else:
            test_size = max(1, int(len(y) * 0.2))  # At least 1 point for testing
            train, test = y.iloc[:-test_size], y.iloc[-test_size:]
        
        # Make predictions with the selected model
        predictions = predict_with_model(best_model, train.reset_index(), test.reset_index())
        
        # Fallback logic if primary model fails
        if predictions is None:
            logger.warning(f"Primary model {best_model} failed, trying fallback models")
            for fallback_model in ['Prophet', 'ETS', 'ARIMA', 'RandomForest']:
                if fallback_model != best_model:
                    predictions = predict_with_model(fallback_model, train.reset_index(), test.reset_index())
                    if predictions is not None:
                        best_model = fallback_model
                        logger.info(f"Using fallback model: {best_model}")
                        break
            
            if predictions is None:
                logger.warning("All models failed, using simple average")
                best_model = "SimpleAverage"
                predictions = [train.mean()] * len(test)
        
        # Calculate MAPE
        try:
            mape = mean_absolute_percentage_error(test, predictions)
        except:
            mape = 0.0  # Default if calculation fails
        
        # Detect anomalies (using modified z-score for robustness)
        residuals = test - predictions
        median_residual = np.median(residuals)
        mad = np.median(np.abs(residuals - median_residual))
        modified_z_scores = 0.6745 * (residuals - median_residual) / mad if mad != 0 else 0
        
        # Convert anomalies to proper array format
        if isinstance(modified_z_scores, (pd.Series, np.ndarray)):
            anomalies = np.array(abs(modified_z_scores) > 3.5)
        else:
            # Handle single value case
            anomalies = np.array([abs(modified_z_scores) > 3.5] * len(test))
        
        # Ensure predictions is array-like
        if not hasattr(predictions, '__len__'):
            predictions = [predictions] * len(test)
        
        # Prepare results with proper anomaly detection
        results = []
        for i in range(len(test)):
            try:
                # Handle case where test might be a single value
                point_value = test.iloc[i] if hasattr(test, 'iloc') else test[i]
                timestamp = test.index[i] if hasattr(test, 'index') else df['timestamp'].iloc[-len(test)+i]
                
                results.append({
                    "timestamp": timestamp.isoformat() if hasattr(timestamp, 'isoformat') else str(timestamp),
                    "point_value": float(point_value),
                    "predicted": float(predictions[i]),
                    "is_anomaly": "yes" if i < len(anomalies) and anomalies[i] else "no"
                })
            except Exception as e:
                logger.warning(f"Error preparing result {i}: {str(e)}")
                continue
        
        return {
            "forecastability_score": max(0, min(10, 10 - mape * 10)),  # Scale to 0-10
            "number_of_batch_fits": 1,
            "mape": float(mape),
            "avg_time_taken_per_fit_in_seconds": 1.2,  # Placeholder
            "best_model": best_model,
            "results": results
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )
@app.get("/", response_class=HTMLResponse)
async def serve_ui():
    try:
        with open("static/index.html", "r") as f:
            return HTMLResponse(content=f.read(), status_code=200)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load UI: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)